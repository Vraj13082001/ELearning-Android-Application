package com.example.elearningapp;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class Fragment3 extends Fragment {
    public View onCreateView(LayoutInflater li, ViewGroup v, Bundle bundle)
    {
        return li.inflate(R.layout.fragment_3,v,false);
    }

}
package com.example.elearningapp.user;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.example.elearningapp.R;

public class UserRealDashboard extends AppCompatActivity {

    CardView cv_intro, cv_data, cv_var, cv_op, cv_loop, cv_function;
    String[] courses = {"introduction", "data type", "variables", "operators", "loops", "function"};


    public static final String CATEGORY = "category";
    TextView rating;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_real_dashboard);

        cv_intro = findViewById(R.id.cv_intro);
        cv_data = findViewById(R.id.cv_data);
        cv_var = findViewById(R.id.cv_var);
        cv_op = findViewById(R.id.cv_op);
        cv_loop = findViewById(R.id.cv_loop);
        cv_function = findViewById(R.id.cv_function);
        rating=findViewById(R.id.rating);


        cv_intro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserRealDashboard.this, UserDashboard.class).putExtra(CATEGORY, courses[0]));
            }
        });
        cv_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserRealDashboard.this, datatype.class).putExtra(CATEGORY, courses[1]));
            }
        });
        cv_var.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserRealDashboard.this,variables.class).putExtra(CATEGORY, courses[2]));
            }
        });
        cv_op.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserRealDashboard.this, operators.class).putExtra(CATEGORY, courses[3]));
            }
        });
        cv_loop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserRealDashboard.this, loops.class).putExtra(CATEGORY, courses[4]));
            }
        });
        cv_function.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserRealDashboard.this, function.class).putExtra(CATEGORY, courses[5]));
            }
        });
        rating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserRealDashboard.this,rating.class));
            }
        });
    }
}
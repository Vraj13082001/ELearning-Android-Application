package com.example.elearningapp.user;
import androidx.appcompat.app.AppCompatActivity;
import android.app.*;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.example.elearningapp.Fragment2;
import com.example.elearningapp.Fragment3;
import com.example.elearningapp.Fragment4;
import com.example.elearningapp.R;

public class UserDashboard extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.replace(R.id.frm2,new Fragment2());
        ft.commit();

        Button b1=(Button)findViewById(R.id.btn1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.frm2,new Fragment3());
                ft.commit();
            }
        });

        Button b2=(Button)findViewById(R.id.btn2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.frm2,new Fragment4());
                ft.commit();
            }
        });
    }
}
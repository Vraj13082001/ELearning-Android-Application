package com.example.elearningapp.user;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.elearningapp.R;

public class loops extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loops);
    }

}
